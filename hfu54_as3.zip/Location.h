/*
name: HSUEH-SHENG FU
Wisc ID: HFU54
*/
#ifndef LOCATION_H
#define LOCATION_H

class Location
{
private:
    std::string name;
    std::string address;
    std::string hours;
    bool allow_reservation;

public:
    Location(std::string name, std::string address, std::string hours, bool allow_reservation);
    Location(const Location &copy_from);
    bool IsReservable() const {return allow_reservation;} 
    std::string to_string() const {return name;}
    void Print() const;
};

#endif
